Asset Doctor RT-PT test package for the zip reader.
